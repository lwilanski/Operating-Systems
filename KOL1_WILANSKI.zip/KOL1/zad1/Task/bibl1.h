#pragma once
  extern int sumuj(int *tab, int n);
  extern double dziel(int a, int b);
